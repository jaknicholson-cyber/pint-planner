/* Pint Planner · original mobile-first static app, no server-side secrets. */
'use strict';
const $ = (id) => document.getElementById(id);
const LS_KEY = 'pint-planner-saves-v1';
const PUB_CACHE_PREFIX = 'pint-planner-pubs-';
const DEFAULT_CENTRE = { lat: 54.973, lon: -1.614, name: 'Newcastle upon Tyne' };
const state = {
  centre: {...DEFAULT_CENTRE},
  pubs: [],
  stops: [],
  route: null,
  weather: null,
  map: null,
  markers: null,
  line: null,
  token: null,
  geolocation: false,
  loadingPubs: false,
  spinning: false
};
let toastTimer, weatherTimer;
const clean = (x) => String(x ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num = (id, lo, hi, fallback) => { const x = Number($(id).value); return Number.isFinite(x) ? Math.min(hi,Math.max(lo,x)) : fallback; };
const isoDate = d => [d.getFullYear(), String(d.getMonth()+1).padStart(2,'0'), String(d.getDate()).padStart(2,'0')].join('-');
const labelDate = date => { const d = new Date(date+'T12:00:00'); return Number.isNaN(d.getTime())?'Choose a date':d.toLocaleDateString('en-GB',{weekday:'short',day:'numeric',month:'short',year:'numeric'}); };
const toClock = (date) => date.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});
const sleep = ms => new Promise(resolve=>setTimeout(resolve,ms));
function toast(message){ const el=$('toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),3800); }
function safeNumber(x,min,max){ const n=Number(x);return Number.isFinite(n)&&n>=min&&n<=max?n:null; }
function getSettings(){
  return {date:$('crawl-date').value,time:$('start-time').value||'13:00',group:num('group-size',1,50,4),pace:num('pint-mins',5,180,35),pints:num('pints-stop',1,8,1),buffer:num('stop-buffer',0,90,10),radius:num('pub-radius',500,5000,2500)};
}
function setSettings(s){
  if(s.date&&/^\d{4}-\d{2}-\d{2}$/.test(s.date)) $('crawl-date').value=s.date;
  if(s.time&&/^\d{2}:\d{2}$/.test(s.time)) $('start-time').value=s.time;
  for(const [key,id,min,max] of [['group','group-size',1,50],['pace','pint-mins',5,180],['pints','pints-stop',1,8],['buffer','stop-buffer',0,90],['radius','pub-radius',500,5000]]){
    const value=safeNumber(s[key],min,max);if(value!==null) $(id).value=value;
  }
}
function distanceMeters(a,b){const r=6371000,dlat=(b.lat-a.lat)*Math.PI/180,dlon=(b.lon-a.lon)*Math.PI/180,x=Math.sin(dlat/2)**2+Math.cos(a.lat*Math.PI/180)*Math.cos(b.lat*Math.PI/180)*Math.sin(dlon/2)**2;return r*2*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));}
function approximateLegs(){const out=[];for(let i=1;i<state.stops.length;i++){const d=distanceMeters(state.stops[i-1],state.stops[i])*1.3;out.push({distance:d,duration:d/1.32});}return out;}
function currentLegs(){return state.route?.legs || approximateLegs();}
function durationInfo(){
  const cfg=getSettings();const legs=currentLegs();const walkingSec=legs.reduce((sum,l)=>sum+l.duration,0);
  const pubMinutes=state.stops.length*(cfg.pace*cfg.pints+cfg.buffer);
  const total=Math.ceil(pubMinutes+walkingSec/60);const start=new Date(cfg.date+'T'+cfg.time+':00');
  const end=new Date(start.getTime()+total*60000);
  const distance=legs.reduce((sum,l)=>sum+l.distance,0);
  return {legs,walkingSec,pubMinutes,total,start,end,distance,valid:!Number.isNaN(start.getTime())};
}
function clearRoute(){state.route=null;if(state.line&&state.map){state.map.removeLayer(state.line);state.line=null;}updateUI();}
function getPubFromOsm(el){const tags=el.tags||{};const lat=el.lat??el.center?.lat,lon=el.lon??el.center?.lon;
  if(typeof lat!=='number'||typeof lon!=='number'||!tags.name) return null;
  const addr=[tags['addr:housenumber'],tags['addr:street'],tags['addr:city']].filter(Boolean).join(' ');
  return {id:el.type+'-'+el.id,name:tags.name.trim().slice(0,120),lat,lon,type:tags.amenity,addr,hours:tags.opening_hours||'',website:tags.website||''};
}
function renderMap(){
  if(!state.map||!window.L)return;
  state.markers.clearLayers();const selected=new Set(state.stops.map(s=>s.id));
  for(const pub of state.pubs){
    const isSelected=selected.has(pub.id);
    const marker=L.marker([pub.lat,pub.lon],{icon:L.divIcon({className:'',html:'<div class="marker-pin'+(isSelected?' selected':'')+'"></div>',iconSize:[26,26],iconAnchor:[13,13]})});
    const id=JSON.stringify(pub.id);
    marker.bindPopup(`<div class="pub-popup"><h4>${clean(pub.name)}</h4><p>${clean(pub.type==='biergarten'?'Beer garden':pub.type==='bar'?'Bar':'Pub')} ${pub.addr?'· '+clean(pub.addr):''}</p><p>${pub.hours?'Hours listed: '+clean(pub.hours):'Opening hours not listed — check before visiting'}</p><button class="popup-add" onclick="window.PintPlanner.add(${clean(id)})">${isSelected?'Already added ✓':'Add to crawl +'}</button></div>`);
    state.markers.addLayer(marker);
  }
  for(const pub of state.stops.filter(s=>s.custom || !state.pubs.some(p=>p.id===s.id))){
    const marker=L.marker([pub.lat,pub.lon],{icon:L.divIcon({className:'',html:'<div class="marker-pin selected"></div>',iconSize:[26,26],iconAnchor:[13,13]})});
    marker.bindPopup(`<div class="pub-popup"><h4>${clean(pub.name)}</h4><p>Custom stop</p></div>`);state.markers.addLayer(marker);
  }
}
function initialiseMap(){
  if(!window.L){$('map').textContent='Map library could not load. Check your internet connection.';return;}
  state.map=L.map('map',{zoomControl:true,scrollWheelZoom:false}).setView([state.centre.lat,state.centre.lon],14);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(state.map);
  state.markers=L.layerGroup().addTo(state.map);
  state.map.on('click',e=>{
    const name=window.prompt('Name this custom stop (pub, meeting point or landmark):');
    if(name&&name.trim()){
      const stop={id:'custom-'+Date.now(),name:name.trim().slice(0,100),lat:e.latlng.lat,lon:e.latlng.lng,type:'custom',custom:true};
      state.stops.push(stop);clearRoute();toast('Custom stop added to your crawl.');
    }
  });
  setTimeout(()=>state.map.invalidateSize(),120);
}
function setCentre(place){
  state.centre={lat:place.lat,lon:place.lon,name:place.name};$('place-input').value=place.name;$('map-location-label').textContent=place.name;
  if(state.map){state.map.setView([place.lat,place.lon],14);state.map.invalidateSize();}
  state.pubs=[];renderMap();refreshWeather();
}
async function findPlace(){
  const q=$('place-input').value.trim();if(q.length<2){toast('Enter a town or city to search.');return;}
  $('find-place').disabled=true;$('find-place').textContent='…';
  try{
    const url='https://geocoding-api.open-meteo.com/v1/search?name='+encodeURIComponent(q)+'&count=8&language=en&format=json&countryCode=GB';
    const response=await fetch(url);if(!response.ok)throw new Error('Location search unavailable');const data=await response.json();
    const matches=(data.results||[]);const preferred=matches.find(x=>x.country_code==='GB')||matches[0];
    if(!preferred)throw new Error('No matching UK location found — try a nearby town or city.');
    setCentre({lat:preferred.latitude,lon:preferred.longitude,name:preferred.name+(preferred.admin1?', '+preferred.admin1:'')});
    await loadPubs();toast('Showing pubs around '+preferred.name+'.');
  }catch(e){toast(e.message||'Could not find that place.');}
  finally{$('find-place').disabled=false;$('find-place').textContent='Find ↗';}
}
function useLocation(){
  if(!navigator.geolocation){toast('Location is not available on this device.');return;}
  toast('Requesting location permission…');
  navigator.geolocation.getCurrentPosition(async position=>{
    setCentre({lat:position.coords.latitude,lon:position.coords.longitude,name:'Near me'});
    state.geolocation=true;await loadPubs();toast('Showing pubs close to your location.');
  },()=>toast('Location was not shared. You can search by town instead.'),{timeout:12000,enableHighAccuracy:false,maximumAge:300000});
}
async function loadPubs(){
  if(state.loadingPubs)return;
  const {lat,lon}=state.centre,radius=getSettings().radius;
  const key=PUB_CACHE_PREFIX+[lat.toFixed(2),lon.toFixed(2),radius].join('-');
  try{const entry=JSON.parse(sessionStorage.getItem(key)||'null');if(entry&&Date.now()-entry.t<30*60*1000){state.pubs=entry.pubs;renderMap();toast(`Found ${state.pubs.length} nearby places (cached).`);return;}}catch{}
  state.loadingPubs=true;const btn=$('nearby-search');btn.disabled=true;btn.textContent='Searching for pubs…';$('roulette-status').textContent='Loading pub locations from OpenStreetMap…';
  const query=`[out:json][timeout:25];(node(around:${radius},${lat},${lon})["amenity"~"^(pub|bar|biergarten)$"];way(around:${radius},${lat},${lon})["amenity"~"^(pub|bar|biergarten)$"];);out center tags;`;
  try{
    const response=await fetch('https://overpass-api.de/api/interpreter',{method:'POST',body:new URLSearchParams({data:query})});
    if(!response.ok)throw new Error(response.status===429?'Pub search is busy; please try again shortly.':'Pub search temporarily unavailable.');
    const data=await response.json();const pubList=(data.elements||[]).map(getPubFromOsm).filter(Boolean);
    const distinct=new Map();pubList.forEach(p=>{const key=p.name.toLowerCase()+'-'+p.lat.toFixed(3)+'-'+p.lon.toFixed(3);if(!distinct.has(key))distinct.set(key,p);});
    state.pubs=[...distinct.values()].sort((a,b)=>distanceMeters(a,state.centre)-distanceMeters(b,state.centre));
    try{sessionStorage.setItem(key,JSON.stringify({t:Date.now(),pubs:state.pubs}));}catch{}
    renderMap();$('roulette-status').textContent=`${state.pubs.length} pubs and bars in your search area. Ready to spin!`;
    toast(state.pubs.length?`${state.pubs.length} pubs and bars found. Tap a green pin to add one.`:'No mapped pubs found. Widen the radius or add custom stops.');
  }catch(e){$('roulette-status').textContent='Pub search unavailable at the moment. Try again from the planner.';toast(e.message||'Could not load pubs.');}
  finally{btn.disabled=false;btn.innerHTML='Find nearby pubs <span>→</span>';state.loadingPubs=false;}
}
function addStop(id){const pub=state.pubs.find(p=>p.id===id);if(!pub){toast('That pub is not in the current search.');return;}if(state.stops.some(s=>s.id===id)){toast('That pub is already on the route.');return;}state.stops.push({...pub});clearRoute();toast(pub.name+' added!');}
function moveStop(index,dir){const target=index+dir;if(target<0||target>=state.stops.length)return;[state.stops[index],state.stops[target]]=[state.stops[target],state.stops[index]];clearRoute();}
function removeStop(index){state.stops.splice(index,1);clearRoute();}
function renderStops(){
  $('stop-count').textContent=state.stops.length+' '+(state.stops.length===1?'pub':'pubs');const root=$('stops-list');
  if(!state.stops.length){root.innerHTML='<div class="empty-stops"><span class="empty-illustration">♧</span><b>No pubs on the list. Yet.</b><p>Find nearby pubs and tap a marker to add it to your crawl.</p></div>';return;}
  const legs=currentLegs();let html='';
  state.stops.forEach((stop,i)=>{
    if(i>0)html+=`<div class="leg-label">↳ ${Math.max(1,Math.ceil((legs[i-1]?.duration||0)/60))} min walk ${state.route?'':'(approx.)'}</div>`;
    html+=`<div class="stop-card"><span class="stop-index">${i+1}</span><div class="stop-info"><strong>${clean(stop.name)}</strong><small>${clean(stop.addr|| (stop.custom?'Custom pin':'Stop '+(i+1)))}</small></div><div class="stop-tools"><button aria-label="Move ${clean(stop.name)} up" onclick="window.PintPlanner.move(${i},-1)" ${i===0?'disabled':''}>↑</button><button aria-label="Move ${clean(stop.name)} down" onclick="window.PintPlanner.move(${i},1)" ${i===state.stops.length-1?'disabled':''}>↓</button><button aria-label="Remove ${clean(stop.name)}" onclick="window.PintPlanner.remove(${i})">×</button></div></div>`;
  });root.innerHTML=html;
}
function updateSummary(){
  const d=durationInfo(),root=$('time-summary');
  if(!state.stops.length){root.innerHTML='<h4>YOUR DAY AT A GLANCE</h4><p>Add a pub or two to see walking times, estimated drinks and your finish time.</p>';return;}
  const cfg=getSettings();const totalPints=state.stops.length*cfg.pints*cfg.group;
  root.innerHTML=`<h4>YOUR DAY AT A GLANCE</h4><div class="summary-times"><div><span>Estimated finish</span><b>${d.valid?toClock(d.end):'—'}</b></div><div><span>Day out duration</span><b>${Math.floor(d.total/60)}h ${String(d.total%60).padStart(2,'0')}m</b></div><div><span>Walking</span><b>${Math.round(d.walkingSec/60)} min</b></div><div><span>Distance</span><b>${(d.distance/1000).toFixed(1)} km</b></div><div><span>Group pints (planned)</span><b>${totalPints}</b></div><div><span>Time in pubs</span><b>${d.pubMinutes} min</b></div></div><p>${state.route?'✓ Walking route calculated on mapped footpaths.':'ⓘ Walking is a rough estimate. Press Calculate walking route for mapped paths.'} Includes ${cfg.buffer} extra minutes per pub for ordering, loos etc. Travel to the first pub is not included.</p>`;
}
function updateUI(){renderStops();renderMap();updateSummary();if(state.weather)renderWeather(state.weather);}
async function calculateRoute(){
  if(state.stops.length<2){toast('Add at least two pubs to calculate a walking route.');return;}
  const button=$('calculate-route');button.disabled=true;button.textContent='Finding walking paths…';
  try{
    const coords=state.stops.map(p=>`${p.lon.toFixed(6)},${p.lat.toFixed(6)}`).join(';');
    const url=`https://routing.openstreetmap.de/routed-foot/route/v1/driving/${coords}?overview=full&geometries=geojson&steps=false`;
    const response=await fetch(url);if(!response.ok)throw new Error('Walking route service is unavailable.');const data=await response.json();
    const route=data.routes?.[0];if(!route||!route.legs||route.legs.length!==state.stops.length-1)throw new Error('No continuous walking route could be found.');
    state.route={legs:route.legs.map(l=>({distance:l.distance,duration:l.duration})),geometry:route.geometry};
    if(state.line&&state.map)state.map.removeLayer(state.line);
    if(state.map&&window.L){state.line=L.geoJSON(route.geometry,{style:{color:'#eb9b3d',weight:5,opacity:.95}}).addTo(state.map);state.map.fitBounds(state.line.getBounds().pad(.15));}
    updateUI();toast('Walking route calculated! Times now use mapped footpaths.');
  }catch(e){state.route=null;updateUI();toast((e.message||'Routing unavailable')+' Showing rough walking estimates instead.');}
  finally{button.disabled=false;button.innerHTML='Calculate walking route <span>→</span>';}
}
async function refreshWeather(){
  const day=$('crawl-date').value;if(!/^\d{4}-\d{2}-\d{2}$/.test(day))return;
  const delta=(new Date(day+'T12:00:00')-new Date(isoDate(new Date())+'T12:00:00'))/86400000;
  if(delta<0){state.weather=null;$('weather-panel').innerHTML='<div class="weather-loading">Choose today or a future date to view the forecast.</div>';return;}
  if(delta>15){state.weather=null;$('weather-panel').innerHTML='<div class="weather-loading">That date is too far ahead for a dependable forecast. Check back when it’s within the next 16 days.</div>';return;}
  const {lat,lon}=state.centre;
  $('weather-panel').innerHTML='<div class="weather-loading">Checking the latest forecast…</div>';
  const requestId=day+':'+lat+':'+lon;refreshWeather.lastRequest=requestId;
  try{
    const url=`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&hourly=temperature_2m,precipitation_probability,cloud_cover,wind_speed_10m,weather_code&timezone=Europe%2FLondon&forecast_days=16`;
    const res=await fetch(url);if(!res.ok)throw new Error('Forecast service temporarily unavailable.');const json=await res.json();
    if(refreshWeather.lastRequest!==requestId)return;
    state.weather=json;renderWeather(json);
  }catch(e){if(refreshWeather.lastRequest===requestId){state.weather=null;$('weather-panel').innerHTML='<div class="weather-loading">Could not load the weather. Check your connection and try changing the date.</div>';}}
}
function mean(values){return values.length?values.reduce((s,x)=>s+x,0)/values.length:0;}
function renderWeather(data){
  const date=$('crawl-date').value,info=durationInfo(),startHour=parseInt(($('start-time').value||'13:00').split(':')[0],10),durationHours=Math.max(2,Math.min(10,Math.ceil(info.total/60)||4));
  const hours=data.hourly?.time||[];const indices=[];for(let i=0;i<hours.length;i++){if(hours[i].startsWith(date+'T')){const h=Number(hours[i].slice(11,13));if(h>=startHour&&h<=Math.min(23,startHour+durationHours))indices.push(i);}}
  if(!indices.length){$('weather-panel').innerHTML='<div class="weather-loading">Hourly weather isn’t available for this date yet.</div>';return;}
  const field=(key)=>indices.map(i=>Number(data.hourly[key]?.[i])).filter(Number.isFinite);
  const temp=Math.round(mean(field('temperature_2m'))),rain=Math.round(mean(field('precipitation_probability'))),cloud=Math.round(mean(field('cloud_cover'))),wind=Math.round(mean(field('wind_speed_10m')));
  const comfortable=temp>=14&&temp<=25&&wind<25;const dry=rain<35;const sunny=cloud<45&&rain<30;
  const label=sunny&&comfortable?'Sunshine & pints':dry&&comfortable?'Beer garden weather':dry?'Jacket-on pints':'Indoor pint weather';
  const symbol=sunny?'☀️':dry?'⛅':'🌧️';const rec=sunny&&comfortable?'Outdoor seating looks promising.':dry&&comfortable?'Outdoors could be worth a shout.':dry?'Check the temperature before choosing outdoor tables.':'Pick pubs with comfortable indoor seating.';
  $('weather-panel').innerHTML=`<div class="weather-grid"><div class="weather-main"><div class="weather-symbol">${symbol}</div><div><b>${clean(label)}</b><small>${clean(labelDate(date))} · ${clean(rec)}</small></div></div><div class="weather-cell"><span>Temperature</span><b>${temp}°C</b><small>Estimated average</small></div><div class="weather-cell"><span>Rain chance</span><b>${rain}%</b><small>Mean hourly chance</small></div><div class="weather-cell"><span>Wind / cloud</span><b>${wind} km/h</b><small>${cloud}% cloud cover</small></div></div><p class="weather-caption">Pint conditions are a fun guide based on hourly weather predictions, not a guarantee of pub seating, sunshine or opening hours. Weather updates when you change date or location, or reload the app.</p>`;
}
function debounceWeather(){clearTimeout(weatherTimer);weatherTimer=setTimeout(refreshWeather,400);}
function planPayload(){const s=getSettings();return {version:1,place:state.centre,settings:s,stops:state.stops.map(({id,name,lat,lon,type,addr,custom})=>({id,name,lat,lon,type,addr,custom}))};}
function applyPayload(payload){
  if(!payload||payload.version!==1||!Array.isArray(payload.stops)||payload.stops.length>35)throw new Error('Invalid crawl data');
  const stops=payload.stops.map(s=>({id:String(s.id||''),name:String(s.name||'Unnamed stop').slice(0,120),lat:safeNumber(s.lat,-90,90),lon:safeNumber(s.lon,-180,180),type:String(s.type||'pub'),addr:String(s.addr||''),custom:!!s.custom}));
  if(stops.some(s=>s.lat===null||s.lon===null))throw new Error('Invalid pub location');
  state.stops=stops;setSettings(payload.settings||{});
  if(payload.place&&safeNumber(payload.place.lat,-90,90)!==null&&safeNumber(payload.place.lon,-180,180)!==null)setCentre({lat:payload.place.lat,lon:payload.place.lon,name:String(payload.place.name||'Your crawl').slice(0,70)});
  clearRoute();renderMap();setTab('planner');toast('Crawl loaded. Walking route can be recalculated.');
}
function encodePlan(x){const bytes=new TextEncoder().encode(JSON.stringify(x));let binary='';bytes.forEach(n=>binary+=String.fromCharCode(n));return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function decodePlan(s){const binary=atob(s.replace(/-/g,'+').replace(/_/g,'/'));return JSON.parse(new TextDecoder().decode(Uint8Array.from(binary,c=>c.charCodeAt(0))));}
function sharingUrl(){const url=new URL(location.href);url.searchParams.set('plan',encodePlan(planPayload()));url.hash='planner';return url.toString();}
async function sharePlan(){if(!state.stops.length){toast('Add at least one pub before sharing.');return;}
  const url=sharingUrl();try{if(navigator.share){await navigator.share({title:'Pint Planner crawl',text:'The plan for '+labelDate(getSettings().date)+' 🍻',url});}else{await navigator.clipboard.writeText(url);toast('Crawl link copied — paste it in your group chat!');}}catch(e){if(e.name!=='AbortError') {window.prompt('Copy your crawl link:',url);}}
}
function escapeIcs(v){return String(v).replace(/\\/g,'\\\\').replace(/\r?\n/g,'\\n').replace(/,/g,'\\,').replace(/;/g,'\\;');}
const icsTime=d=>d.toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,'');
function calendarDetails(){if(!state.stops.length)throw new Error('Add at least one pub first.');const d=durationInfo();if(!d.valid)throw new Error('Choose a valid date and time.');const text=state.stops.map((s,i)=>`${i+1}. ${s.name}`).join('\n');return {d,title:'Pint Planner: Pub crawl 🍻',description:`Pub crawl with ${getSettings().group} people.\n\nStops:\n${text}\n\nEstimated walking: ${Math.round(d.walkingSec/60)} minutes.\nExpected finish: ${toClock(d.end)}.\n\nPlan: ${sharingUrl()}`};}
function downloadCalendar(){
  try{const {d,title,description}=calendarDetails();const ics=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Pint Planner//UK//EN','CALSCALE:GREGORIAN','METHOD:PUBLISH','BEGIN:VEVENT','UID:'+Date.now()+'@pintplanner.local','DTSTAMP:'+icsTime(new Date()),'DTSTART:'+icsTime(d.start),'DTEND:'+icsTime(d.end),'SUMMARY:'+escapeIcs(title),'DESCRIPTION:'+escapeIcs(description),'LOCATION:'+escapeIcs(state.stops[0].name),'END:VEVENT','END:VCALENDAR'].join('\r\n');
    const blob=new Blob([ics],{type:'text/calendar;charset=utf-8'});const object=URL.createObjectURL(blob);const a=document.createElement('a');a.href=object;a.download='pint-planner-'+getSettings().date+'.ics';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(object),2000);toast('Calendar event downloaded. Open it to add to your calendar.');
  }catch(e){toast(e.message);}
}
function addGoogleEvent(){try{const {d,title,description}=calendarDetails();const p=new URLSearchParams({action:'TEMPLATE',text:title,dates:icsTime(d.start)+'/'+icsTime(d.end),details:description,location:state.stops[0].name});window.open('https://calendar.google.com/calendar/render?'+p,'_blank','noopener,noreferrer');}catch(e){toast(e.message);}}
function getSaved(){try{const items=JSON.parse(localStorage.getItem(LS_KEY)||'[]');return Array.isArray(items)?items:[];}catch{return [];}}
function savePlan(){if(!state.stops.length){toast('Choose some pubs before saving your crawl.');return;}const payload=planPayload();const records=getSaved();const id='crawl-'+Date.now();records.unshift({id,created:Date.now(),payload});try{localStorage.setItem(LS_KEY,JSON.stringify(records.slice(0,25)));toast('Crawl saved on this device.');renderSaved();}catch{toast('Could not save to device storage.');}}
function deleteSaved(id){const records=getSaved().filter(r=>r.id!==id);localStorage.setItem(LS_KEY,JSON.stringify(records));renderSaved();toast('Saved crawl removed.');}
function loadSaved(id){const record=getSaved().find(x=>x.id===id);if(record)try{applyPayload(record.payload);}catch(e){toast(e.message);}}
function renderSaved(){const root=$('saved-list');const records=getSaved();if(!records.length){root.innerHTML='<div class="saved-empty"><h3>No saved crawls yet.</h3><p>Build a route in the Planner and hit “Save this crawl”. It will show up here.</p></div>';return;}
  root.innerHTML=records.map(r=>`<article class="saved-card"><span class="eyebrow">SAVED CRAWL</span><h3>${clean(labelDate(r.payload?.settings?.date||''))}</h3><p>${clean(r.payload?.place?.name||'Your town')} · ${r.payload?.stops?.length||0} stops</p><div class="row-btns"><button class="btn btn-dark" onclick="window.PintPlanner.loadSaved(${clean(JSON.stringify(r.id))})">Open plan ↗</button><button class="btn btn-outline" onclick="window.PintPlanner.deleteSaved(${clean(JSON.stringify(r.id))})">Delete</button></div></article>`).join('');
}
function setTab(tab){if(!['planner','roulette','saved'].includes(tab))return;document.querySelectorAll('.page').forEach(el=>el.classList.toggle('active',el.id==='page-'+tab));document.querySelectorAll('[data-tab]').forEach(el=>el.classList.toggle('active',el.dataset.tab===tab));history.replaceState(null,'',location.pathname+location.search+'#'+tab);if(tab==='planner'&&state.map)setTimeout(()=>state.map.invalidateSize(),90);if(tab==='saved')renderSaved();window.scrollTo({top:0,behavior:'instant'});}
async function spinRoulette(){if(state.spinning)return;if(!state.pubs.length)await loadPubs();if(!state.pubs.length){toast('No pubs found. Search another town or radius on the Planner page.');return;}
  let list=state.pubs.filter(p=>$('roulette-bars').checked||p.type==='pub');if($('roulette-exclude').checked)list=list.filter(p=>!state.stops.some(s=>s.id===p.id));
  if(!list.length){toast('No pubs match these filters. Untick one of the options.');return;}
  const choice=list[Math.floor(Math.random()*list.length)];state.spinning=true;
  $('roulette-spin').disabled=true;$('roulette-wheel').classList.add('spinning');$('roulette-status').textContent='Shuffling your next round…';$('roulette-result').hidden=true;
  await sleep(1150);$('roulette-wheel').classList.remove('spinning');state.spinning=false;$('roulette-spin').disabled=false;
  $('roulette-status').textContent='The next round is calling…';
  const directions='https://www.google.com/maps/dir/?api=1&destination='+encodeURIComponent(choice.lat+','+choice.lon)+'&travelmode=walking';
  $('roulette-result').innerHTML=`<span class="eyebrow">YOUR NEXT STOP</span><h3>${clean(choice.name)}</h3><p>${clean(choice.addr||'Pub / bar')} · ${Math.round(distanceMeters(choice,state.centre))} m from search centre</p><p>${choice.hours?'Listed hours: '+clean(choice.hours):'Opening hours not verified — check before setting off.'}</p><div class="result-actions"><button class="btn btn-dark" onclick="window.PintPlanner.add(${clean(JSON.stringify(choice.id))})">Add to crawl +</button><a class="btn btn-outline" target="_blank" rel="noopener noreferrer" href="${directions}">Walking directions ↗</a></div>`;
  $('roulette-result').hidden=false;
}
async function connectCalendar(){
  const id=window.PINT_PLANNER_CONFIG?.googleClientId;
  if(!id){toast('Calendar linking requires a Google OAuth Client ID. See README for setup.');return;}
  if(!window.google?.accounts?.oauth2){toast('Google sign-in is not ready. Reload and try again.');return;}
  const client=google.accounts.oauth2.initTokenClient({client_id:id,scope:'https://www.googleapis.com/auth/calendar.readonly',callback:async res=>{
    if(res.error||!res.access_token){toast('Calendar connection was not completed.');return;}
    state.token=res.access_token;$('calendar-status').textContent='Google Calendar connected for this session';$('calendar-connect').textContent='Refresh schedule';$('calendar-disconnect').hidden=false;await loadCalendarClashes();
  }});
  if(state.token) await loadCalendarClashes();else client.requestAccessToken({prompt:'consent'});
}
async function loadCalendarClashes(){if(!state.token)return;const s=getSettings();const d=new Date(s.date+'T00:00:00');if(Number.isNaN(d.getTime()))return;const end=new Date(d.getTime()+86400000);
  const url=new URL('https://www.googleapis.com/calendar/v3/calendars/primary/events');url.searchParams.set('timeMin',d.toISOString());url.searchParams.set('timeMax',end.toISOString());url.searchParams.set('singleEvents','true');url.searchParams.set('orderBy','startTime');url.searchParams.set('maxResults','40');
  try{const res=await fetch(url,{headers:{Authorization:'Bearer '+state.token}});if(!res.ok)throw new Error(res.status===401?'Session expired. Connect again.':'Google Calendar request failed.');const json=await res.json();
    const info=durationInfo();const clashes=(json.items||[]).filter(x=>{const start=x.start?.dateTime?new Date(x.start.dateTime):new Date(x.start?.date+'T00:00:00');const end=x.end?.dateTime?new Date(x.end.dateTime):new Date(x.end?.date+'T00:00:00');return start<info.end&&end>info.start;});
    $('calendar-clashes').innerHTML=clashes.length?`<b>Potential clashes with your crawl:</b>${clashes.map(x=>`<div class="clash-item">${clean(x.summary||'Busy event')} · ${clean(x.start?.dateTime?toClock(new Date(x.start.dateTime)):'All-day event')}</div>`).join('')}`:'✓ No clashes found in your primary calendar for the planned time.';
  }catch(e){$('calendar-clashes').textContent=e.message;toast(e.message);}
}
function disconnectCalendar(){if(state.token&&window.google?.accounts?.oauth2)google.accounts.oauth2.revoke(state.token,()=>{});state.token=null;$('calendar-status').textContent='Not connected';$('calendar-clashes').textContent='';$('calendar-connect').textContent='Connect calendar';$('calendar-disconnect').hidden=true;toast('Disconnected for this session.');}
function init(){
  $('crawl-date').value=isoDate(new Date());$('today-text').textContent=new Date().toLocaleDateString('en-GB',{weekday:'short',day:'numeric',month:'short'});
  initialiseMap();
  for(const button of document.querySelectorAll('[data-tab]'))button.addEventListener('click',()=>setTab(button.dataset.tab));
  $('find-place').addEventListener('click',findPlace);$('place-input').addEventListener('keydown',e=>{if(e.key==='Enter')findPlace();});
  $('use-my-location').addEventListener('click',useLocation);$('nearby-search').addEventListener('click',loadPubs);$('calculate-route').addEventListener('click',calculateRoute);
  $('save-plan').addEventListener('click',savePlan);$('share-plan').addEventListener('click',sharePlan);$('download-ics').addEventListener('click',downloadCalendar);$('google-add').addEventListener('click',addGoogleEvent);
  $('roulette-spin').addEventListener('click',spinRoulette);$('calendar-connect').addEventListener('click',connectCalendar);$('calendar-disconnect').addEventListener('click',disconnectCalendar);
  for(const id of ['crawl-date','start-time','group-size','pint-mins','pints-stop','stop-buffer'])$(id).addEventListener('change',()=>{clearRoute();if(id==='crawl-date'||id==='start-time')debounceWeather();});
  $('pub-radius').addEventListener('change',()=>toast('Press “Find nearby pubs” to search the new radius.'));
  window.PintPlanner={add:addStop,remove:removeStop,move:moveStop,loadSaved,deleteSaved};
  const params=new URL(location.href).searchParams;
  if(params.has('plan')){try{applyPayload(decodePlan(params.get('plan')));}catch(e){toast('The shared plan link could not be read.');}}
  const hash=location.hash.slice(1);if(['planner','roulette','saved'].includes(hash))setTab(hash);
  renderSaved();updateUI();refreshWeather();
  // Light initial query so opening the app is useful immediately. Cached in session.
  loadPubs();
  if('serviceWorker' in navigator&&location.protocol==='https:')navigator.serviceWorker.register('./sw.js').catch(()=>{});
}
document.addEventListener('DOMContentLoaded',init);
