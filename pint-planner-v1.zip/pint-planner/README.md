# Pint Planner 🍺

**A free, mobile-first pub-crawl planner designed for GitHub Pages.**

Original interface and code. Pub Roulette is *inspired by* [Pub Roulette](https://barmstrong9.github.io/pub-roulette/) — this project does not copy that repository's code or assets.

## What's included

- **Crawl planner:** Find pubs and bars from OpenStreetMap; tap pub markers to add them to a route; add custom stops by tapping empty space on the map; rearrange and remove stops.
- **Real walking routes:** OSRM pedestrian directions when you press **Calculate walking route**, with a clearly labelled straight-line rough estimate when not yet calculated or if routing fails.
- **Day length:** Group size, minutes per pint *per person*, pints per stop and buffer time; shows expected finish time, walking duration, pub time, group pint count and distance. Group members drink concurrently, so group size does not multiply pub time. Excludes travel to first pub.
- **Pint forecast:** Open-Meteo weather for your chosen date and location, plus fun beer-garden versus indoor suggestions. Available up to 16 days ahead; no weather guarantees.
- **Pub Roulette:** Random choice from nearby pubs, optional inclusion of bars and beer gardens, optionally excluding pubs on your route, reroll, add to route and Google walking directions. Pub opening hours are displayed where available but not independently verified or filtered.
- **Save and share:** Device-only local saved crawls; shareable crawl URL; export `.ics` calendar event; open a prefilled Google Calendar event.
- **Optional Google Calendar read integration:** Connect *your own* Google Calendar via browser OAuth and check your primary calendar for events that overlap your planned crawl. Requires configuring your own Google Cloud project (see below).
- **Installable:** Web app manifest, app icons and service worker for GitHub Pages / iPhone Home Screen.

## Publish on GitHub Pages (no command line)

1. Make a free GitHub account at https://github.com/signup.
2. At https://github.com/new create a **Public** repository called `pint-planner`. Tick **Add a README file**.
3. Download the project ZIP from ChatGPT and **extract** the ZIP on your phone or computer.
4. Open your GitHub `pint-planner` repository. Select **Add file → Upload files**.
5. Upload **the files and `icons` folder INSIDE the extracted `pint-planner` folder**, not the ZIP itself. Make sure `index.html`, `app.js` and `styles.css` appear at the **top level** of the repository, not inside another folder. GitHub lets you drag a folder onto its upload surface from a desktop computer.
6. Press **Commit changes**.
7. Under **Settings → Pages**, select **Deploy from a branch**. Select `main` and `/(root)`, then **Save**.
8. Open `https://YOUR-GITHUB-USERNAME.github.io/pint-planner/` once Pages finishes deploying.
9. On iPhone, open the website in **Safari → Share → Add to Home Screen**.

**IMPORTANT:** GitHub Pages publishes your front-end code publicly. Never store passwords, API secrets, private calendar data, or personal invitations in the repository. Shared crawl links encode locations and timings in the URL — only share them with people you trust, and avoid adding private home addresses to public plans.

## Optional Google Calendar connection (additional configuration)

The Google Calendar **event link** and `.ics` **Add to calendar** features work straight away, without setup. **Reading availability from Google Calendar** is optional and requires extra steps:

1. Create a Google Cloud project at https://console.cloud.google.com/.
2. Enable the **Google Calendar API**.
3. Configure a Google Auth Platform consent screen and request `https://www.googleapis.com/auth/calendar.readonly`. Depending on account type/audience, Google may require verification before the app can be used by the public; while testing, add yourself as an authorised test user.
4. Create an **OAuth client ID** of type **Web application**. Set the **Authorised JavaScript origin** to `https://YOUR-GITHUB-USERNAME.github.io` (origin only — no path).
5. Copy the **public** client ID (NOT a client secret) to `googleClientId` in `config.js`, commit and redeploy.
6. In Pint Planner → **Saved plans**, press **Connect calendar**. The app requests Google Calendar *read-only* access and checks calendar clashes for your chosen crawl date. The access token stays in browser memory rather than being stored on a server or in localStorage.

This is **not a multi-user scheduling backend**. Every person can open/share the plan and add it to their calendar, but automatic aggregation of everyone’s free/busy data, invitations/RSVPs, private groups, and continuous calendar synchronisation require a subsequent secure backend and authentication design. Do not put OAuth client secrets in `config.js`.

## External data and rate-limit notes

- **Pub locations:** Overpass API over OpenStreetMap; pub data may be incomplete, opening times may be outdated. Pub searches occur on app load or explicit request; results cached in the browser session for 30 minutes. Free public Overpass capacity is shared and not suitable for large scale deployment. https://wiki.openstreetmap.org/wiki/Overpass_API
- **Map tiles:** OpenStreetMap standard tiles. Attribution appears on the map and footer; follow the tile usage policy. https://operations.osmfoundation.org/policies/tiles/
- **Walking directions:** Public OSRM foot routing by FOSSGIS. Query only on demand. Max one request per second (this app uses one request per multi-stop route). No guarantee of response/uptime. https://routing.openstreetmap.de/about.html
- **Weather:** Open-Meteo hourly forecasts, up to 16 days; free for non-commercial use subject to limits and attribution. See https://open-meteo.com/en/terms. The forecast is not a promise that a venue will have outdoor seating.
- **Maps:** Leaflet loaded from a public CDN. An internet connection is necessary to load map tiles and external data, even though the app shell can be cached for later visits.

## Test locally

Use a local HTTP server rather than opening `index.html` via a `file://` URL. For example:

```sh
python3 -m http.server 8080
```

Visit `http://localhost:8080/`. GPS location usually needs HTTPS outside localhost, which GitHub Pages provides.

## Roadmap for a fully fledged social app

1. **Shared groups + RSVP**: Firebase or Supabase authentication/database with permissions for each event and participant.
2. **Calendar sync for all attendees**: Permissioned integrations and secure token handling, availability only (unless user permits more), invitations and RSVP tracking.
3. **Venue enrichments**: More reliable opening-hours verification, photos and outdoor seating where the data is licensed and accurate.
4. **Production infrastructure**: Managed pub search/geocoding and pedestrian routing instead of shared free public endpoints.
5. **Private events**: Proper access control rather than relying on obscurity of a share link.
6. **More detailed forecast**: Rain over the actual route, time-at-venue suggestions and sensible alerts.

## Privacy

Saved plans are stored only in the current browser's localStorage. The app's browser requests send map areas, pub coordinates or weather coordinates to the respective public services. `Share crawl` puts dates, pub names and positions into a URL — anyone with that URL can read the plan. Optional Google Calendar requests go directly from your browser to Google's API using short-lived access tokens. No user account or bespoke database exists in v1.
