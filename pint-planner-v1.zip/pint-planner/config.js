// Optional: create a Web OAuth client in Google Cloud and paste its PUBLIC client ID here.
// Never put a client secret, access token, or API key intended to be secret in a GitHub Pages repository.
window.PINT_PLANNER_CONFIG = {
  googleClientId: ''
};
